# VOXIA local model pack

VOXIA supports a unified gateway contract for local engines. The project catalog includes:

- Kokoro-82M — Apache-2.0 weights
- Piper — local neural TTS (GPL engine; individual voice licenses vary)
- Chatterbox Multilingual V3 / Turbo — MIT open source, expressive controls
- F5-TTS — MIT code; pretrained model license must be checked for your use
- CosyVoice 3 — open-source multilingual TTS; check model license
- Qwen3-TTS — open-source voice design/cloning/streaming; check model card
- Fish Speech S2 Pro — Fish Audio Research License; check restrictions

Only install/download models whose licenses permit your intended use and only clone voices you have permission to use.

For the two built-in gateway adapters:

    pip install fastapi uvicorn soundfile numpy
    pip install kokoro piper-tts
    uvicorn local_tts_gateway:app --host 0.0.0.0 --port 8099

For Chatterbox/F5/CosyVoice/Qwen/Fish, run the official server from the model's repository and either:
1. add an adapter to `local_tts_gateway.py`, or
2. expose a small `/tts` bridge matching the contract below.

POST /tts:
{
  "provider": "...",
  "model": "...",
  "voice": "...",
  "text": "...",
  "speed": 1.0
}

Response:
{"audio_base64":"...","content_type":"audio/wav"}
