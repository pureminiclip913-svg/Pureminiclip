# VOXIA Neural TTS 2.0

A multi-engine, futuristic text-to-speech studio built on the supplied VOXIA repository.

## What is new

VOXIA is no longer hard-wired to one TTS vendor. The backend now has a provider router and a model catalog covering premium APIs plus open/local engines.

### Cloud/API engines
- ElevenLabs v3 / Multilingual v2 / Flash v2.5
- OpenAI GPT-4o mini TTS / TTS-1 HD
- Deepgram Aura-2
- Cartesia Sonic 3
- Google Gemini 3.1 Flash TTS
- Google Gemini 2.5 Flash TTS
- Google Gemini 2.5 Pro TTS
- Azure Neural Speech

### Local/free/open model catalog
- Kokoro-82M
- Piper
- Chatterbox Multilingual V3
- Chatterbox Turbo
- F5-TTS
- CosyVoice 3
- Qwen3-TTS
- Fish Speech S2 Pro

The catalog is deliberately extensible: new engines can be added to `backend/services/engineRegistry.ts` and implemented as adapters in `backend/services/ttsService.ts`.

## Important reality check

No application can literally contain *every* TTS model and *every* API on the internet. Models, API contracts, licenses, endpoints, and free tiers change continuously. This build therefore uses a provider-adapter architecture instead of pretending that a static list is complete.

It also does not claim that one model is objectively better than ElevenLabs. The router lets you benchmark engines on the same script and choose quality, speed, language coverage, or cost.

## Setup

1. Install Node.js 20+.
2. Copy `.env.example` to `.env`.
3. Add one or more API keys.
4. Run:

```bash
npm install
npm run dev
```

The web app is served by the Express/Vite server.

## Free/local mode

Run the included gateway:

```bash
pip install fastapi uvicorn soundfile numpy
pip install kokoro piper-tts
uvicorn local_tts_gateway:app --host 0.0.0.0 --port 8099
```

Then set:

```env
LOCAL_TTS_URL=http://127.0.0.1:8099
```

Kokoro and Piper can then be selected from the Studio.

For Chatterbox, F5-TTS, CosyVoice, Qwen3-TTS and Fish Speech, use their official local servers and add a small adapter to the gateway. Do not download or use a model unless its license permits your intended use.

## Security

- API keys stay on the backend.
- Browser requests never receive provider secrets.
- CORS is no longer an unconditional allow-all policy.
- Provider errors are returned without exposing secrets.
- Local voice cloning should only be used with voices you have permission to clone.

## Provider references

Official documentation/repositories used while designing the adapter catalog:

- ElevenLabs: https://elevenlabs.io/docs
- OpenAI TTS: https://platform.openai.com/docs/guides/text-to-speech
- Deepgram Aura: https://developers.deepgram.com/docs/text-to-speech
- Cartesia: https://docs.cartesia.ai/
- Google Gemini TTS: https://ai.google.dev/gemini-api/docs/speech-generation
- Azure Speech: https://learn.microsoft.com/azure/ai-services/speech-service/rest-text-to-speech
- Amazon Polly: https://docs.aws.amazon.com/polly/
- Kokoro: https://huggingface.co/hexgrad/Kokoro-82M
- Chatterbox: https://github.com/resemble-ai/chatterbox
- F5-TTS: https://github.com/SWivid/F5-TTS
- CosyVoice: https://github.com/FunAudioLLM/CosyVoice
- Qwen3-TTS: https://github.com/QwenLM/Qwen3-TTS
- Fish Speech: https://github.com/fishaudio/fish-speech
- Piper: https://github.com/OHF-Voice/piper1-gpl

## Soniox

There are no Soniox integrations or `SONIOX_API_KEY` references in this repository.
