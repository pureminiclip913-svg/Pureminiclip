# TTS model registry

The UI catalog is in `backend/services/engineRegistry.ts`.

Current entries:
- ElevenLabs: v3, Multilingual v2, Flash v2.5
- OpenAI: GPT-4o mini TTS, TTS-1 HD
- Deepgram: Aura-2 Thalia, Aura-2 Andromeda
- Cartesia: Sonic 3
- Gemini: 3.1 Flash TTS, 2.5 Flash TTS, 2.5 Pro TTS
- Azure: Neural Speech
- Local: Kokoro-82M, Piper, Chatterbox V3, Chatterbox Turbo, F5-TTS, CosyVoice 3, Qwen3-TTS, Fish Speech S2 Pro

The catalog is not a claim that these are the only TTS systems in existence. It is a maintainable set of production API adapters plus open/local engines.
