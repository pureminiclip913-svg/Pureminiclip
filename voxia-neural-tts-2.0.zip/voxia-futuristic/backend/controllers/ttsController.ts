import { Request, Response, NextFunction } from 'express';
import { ttsService } from '../services/ttsService.js';
import { storageService } from '../services/storageService.js';
import { databaseService } from '../services/databaseService.js';
import { voiceService } from '../services/voiceService.js';
import { usageService } from '../services/usageService.js';
import { GenerationRecord } from '../types.js';

function normalizeModel(id:string){
  return id.includes(':') ? id : `elevenlabs:${id}`;
}

export async function generateTTS(req:Request,res:Response,next:NextFunction):Promise<void>{
  try{
    const {text,voiceId,modelId='elevenlabs:eleven_multilingual_v2',stability=.5,similarity=.75,style=0,speed=1,outputFormat='mp3_44100_128',projectId}=req.body;
    const trimmed=String(text||'').trim();
    const model=normalizeModel(String(modelId));
    if(!trimmed||!voiceId){res.status(400).json({success:false,error:{code:'INVALID_REQUEST',message:'text and voiceId are required'}});return;}
    if(!(await usageService.hasAvailableQuota(trimmed.length))){res.status(403).json({success:false,error:{code:'QUOTA_EXCEEDED',message:'Character quota exceeded.'}});return;}
    const voice=await voiceService.getVoiceById(voiceId);
    const voiceName=voice?.name||voiceId;
    const result=await ttsService.generateSpeech({text:trimmed,voiceId,modelId:model,stability:Number(stability),similarity_boost:Number(similarity),style:Number(style),speed:Number(speed),outputFormat});
    const wordCount=trimmed.split(/\s+/).filter(Boolean).length;
    const duration=Math.max(1,Math.round(wordCount/140*60));
    const genId=`gen_${Date.now()}_${Math.random().toString(36).slice(2,9)}`;
    const ext=result.format;
    const file=`voxia-${Date.now()}.${ext}`;
    await usageService.trackGeneration(trimmed.length);
    const record:GenerationRecord={id:genId,text:trimmed,voiceId,voiceName,modelId:model,audioUrl:`/api/audio/${file}`,audioFileName:file,format:ext,characterCount:trimmed.length,wordCount,durationSeconds:duration,createdAt:new Date().toISOString(),status:'completed',settings:{stability:Number(stability),similarity_boost:Number(similarity),style:Number(style),use_speaker_boost:true,speed:Number(speed)},projectId};
    await databaseService.createGeneration(record);
    storageService.cacheAudioInMemory(genId,result.audioBuffer,result.contentType,file);
    res.writeHead(200,{'Content-Type':result.contentType,'Content-Length':result.audioBuffer.length,'Content-Disposition':`inline; filename="${file}"`,'X-Generation-Id':genId,'X-Voice-Name':encodeURIComponent(voiceName),'X-Voice-Id':voiceId,'X-Model-Id':model,'X-Character-Count':String(trimmed.length),'X-Word-Count':String(wordCount),'X-Duration-Seconds':String(duration),'X-Audio-Format':ext,'X-Download-Filename':file});
    res.end(result.audioBuffer);
  }catch(e){next(e);}
}

export async function streamTTS(req:Request,res:Response,next:NextFunction):Promise<void>{
  try{
    const {text,voiceId,modelId='elevenlabs:eleven_multilingual_v2',stability=.5,similarity=.75,style=0,speed=1,outputFormat='mp3_44100_128'}=req.body;
    const trimmed=String(text||'').trim();
    const model=normalizeModel(String(modelId));
    if(!(await usageService.hasAvailableQuota(trimmed.length))){res.status(403).json({success:false,error:{code:'QUOTA_EXCEEDED',message:'Character quota exceeded.'}});return;}
    const voice=await voiceService.getVoiceById(voiceId);
    const result=await ttsService.generateSpeech({text:trimmed,voiceId,modelId:model,stability:Number(stability),similarity_boost:Number(similarity),style:Number(style),speed:Number(speed),outputFormat});
    const wordCount=trimmed.split(/\s+/).filter(Boolean).length;
    const duration=Math.max(1,Math.round(wordCount/140*60));
    const file=`voxia-${Date.now()}.${result.format}`;
    res.writeHead(200,{'Content-Type':result.contentType,'Content-Length':result.audioBuffer.length,'X-Voxia-Streaming':'true','X-Voice-Name':encodeURIComponent(voice?.name||voiceId),'X-Model-Id':model,'X-Audio-Format':result.format,'X-Download-Filename':file,'X-Character-Count':String(trimmed.length),'X-Word-Count':String(wordCount),'X-Duration-Seconds':String(duration)});
    res.end(result.audioBuffer);
    await usageService.trackGeneration(trimmed.length);
  }catch(e){next(e);}
}
