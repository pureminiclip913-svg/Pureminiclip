import { Voice } from '../types.js';

export type EngineProvider =
  | 'elevenlabs' | 'openai' | 'deepgram' | 'cartesia' | 'gemini' | 'azure'
  | 'local-kokoro' | 'local-piper' | 'local-chatterbox' | 'local-f5tts'
  | 'local-cosyvoice' | 'local-qwen3tts' | 'local-fishspeech';

export interface EngineDefinition {
  id: string;
  provider: EngineProvider;
  name: string;
  description: string;
  languages: string;
  tier: 'cloud' | 'free-tier' | 'local';
  quality: number;
  latency: string;
  voiceId: string;
  envKey?: string;
  requiresLocalServer?: boolean;
}

export const ENGINE_DEFINITIONS: EngineDefinition[] = [
  { id:'elevenlabs:eleven_v3', provider:'elevenlabs', name:'Eleven v3', description:'Expressive premium synthesis.', languages:'70+', tier:'cloud', quality:10, latency:'low', voiceId:'21m00Tcm4TlvDq8ikWAM', envKey:'ELEVENLABS_API_KEY' },
  { id:'elevenlabs:eleven_multilingual_v2', provider:'elevenlabs', name:'Eleven Multilingual v2', description:'Natural multilingual synthesis.', languages:'29+', tier:'cloud', quality:9.8, latency:'low', voiceId:'21m00Tcm4TlvDq8ikWAM', envKey:'ELEVENLABS_API_KEY' },
  { id:'elevenlabs:eleven_flash_v2_5', provider:'elevenlabs', name:'Eleven Flash v2.5', description:'Low-latency conversational synthesis.', languages:'32+', tier:'cloud', quality:9.5, latency:'ultra-low', voiceId:'21m00Tcm4TlvDq8ikWAM', envKey:'ELEVENLABS_API_KEY' },

  { id:'openai:gpt-4o-mini-tts', provider:'openai', name:'OpenAI GPT-4o mini TTS', description:'Instruction-steerable speech generation.', languages:'multilingual', tier:'cloud', quality:9.4, latency:'low', voiceId:'alloy', envKey:'OPENAI_API_KEY' },
  { id:'openai:tts-1-hd', provider:'openai', name:'OpenAI TTS-1 HD', description:'High quality speech synthesis.', languages:'multilingual', tier:'cloud', quality:9.1, latency:'low', voiceId:'alloy', envKey:'OPENAI_API_KEY' },

  { id:'deepgram:aura-2-thalia-en', provider:'deepgram', name:'Deepgram Aura-2 Thalia', description:'Fast natural English TTS.', languages:'English', tier:'cloud', quality:9.1, latency:'ultra-low', voiceId:'aura-2-thalia-en', envKey:'DEEPGRAM_API_KEY' },
  { id:'deepgram:aura-2-andromeda-en', provider:'deepgram', name:'Deepgram Aura-2 Andromeda', description:'Fast conversational English TTS.', languages:'English', tier:'cloud', quality:9.1, latency:'ultra-low', voiceId:'aura-2-andromeda-en', envKey:'DEEPGRAM_API_KEY' },

  { id:'cartesia:sonic-3', provider:'cartesia', name:'Cartesia Sonic 3', description:'Realtime expressive voice generation.', languages:'multilingual', tier:'cloud', quality:9.5, latency:'ultra-low', voiceId:'694f9389-aac1-45b6-b726-9d9369183238', envKey:'CARTESIA_API_KEY' },

  { id:'gemini:gemini-3.1-flash-tts-preview', provider:'gemini', name:'Gemini 3.1 Flash TTS', description:'Controllable expressive TTS with natural-language direction.', languages:'multilingual', tier:'free-tier', quality:9.5, latency:'low', voiceId:'Kore', envKey:'GEMINI_API_KEY' },
  { id:'gemini:gemini-2.5-flash-preview-tts', provider:'gemini', name:'Gemini 2.5 Flash TTS', description:'Fast controllable speech generation.', languages:'multilingual', tier:'free-tier', quality:9.2, latency:'low', voiceId:'Kore', envKey:'GEMINI_API_KEY' },
  { id:'gemini:gemini-2.5-pro-preview-tts', provider:'gemini', name:'Gemini 2.5 Pro TTS', description:'High-fidelity structured narration.', languages:'multilingual', tier:'cloud', quality:9.7, latency:'medium', voiceId:'Kore', envKey:'GEMINI_API_KEY' },

  { id:'azure:neural', provider:'azure', name:'Azure Neural Speech', description:'Enterprise neural voices and SSML.', languages:'many', tier:'cloud', quality:9.0, latency:'low', voiceId:'en-US-AvaMultilingualNeural', envKey:'AZURE_SPEECH_KEY' },

  { id:'local-kokoro:Kokoro-82M', provider:'local-kokoro', name:'Kokoro 82M', description:'Lightweight Apache-2.0 open-weight TTS.', languages:'English', tier:'local', quality:8.8, latency:'fast', voiceId:'af_heart', requiresLocalServer:true },
  { id:'local-piper:piper', provider:'local-piper', name:'Piper', description:'Fast local neural TTS with a huge voice catalog.', languages:'many', tier:'local', quality:8.0, latency:'very fast', voiceId:'en_US-lessac-medium', requiresLocalServer:true },
  { id:'local-chatterbox:multilingual-v3', provider:'local-chatterbox', name:'Chatterbox Multilingual V3', description:'Open-source multilingual zero-shot cloning and emotion control.', languages:'23+', tier:'local', quality:9.7, latency:'low', voiceId:'reference', requiresLocalServer:true },
  { id:'local-chatterbox:turbo', provider:'local-chatterbox', name:'Chatterbox Turbo', description:'350M low-latency TTS with paralinguistic tags.', languages:'English', tier:'local', quality:9.5, latency:'ultra-low', voiceId:'reference', requiresLocalServer:true },
  { id:'local-f5tts:F5-TTS', provider:'local-f5tts', name:'F5-TTS', description:'Flow-matching zero-shot voice cloning.', languages:'multilingual', tier:'local', quality:9.3, latency:'low', voiceId:'reference', requiresLocalServer:true },
  { id:'local-cosyvoice:CosyVoice3', provider:'local-cosyvoice', name:'CosyVoice 3', description:'Multilingual zero-shot synthesis with strong speaker similarity.', languages:'multilingual', tier:'local', quality:9.5, latency:'low', voiceId:'reference', requiresLocalServer:true },
  { id:'local-qwen3tts:Qwen3-TTS', provider:'local-qwen3tts', name:'Qwen3-TTS', description:'Voice design, cloning, expressive and streaming speech.', languages:'multilingual', tier:'local', quality:9.6, latency:'low', voiceId:'reference', requiresLocalServer:true },
  { id:'local-fishspeech:Fish-Speech-S2-Pro', provider:'local-fishspeech', name:'Fish Speech S2 Pro', description:'Large multilingual expressive TTS with natural-language emotion tags.', languages:'80+', tier:'local', quality:9.7, latency:'medium', voiceId:'reference', requiresLocalServer:true },
];

export function engineCatalog(): EngineDefinition[] {
  return ENGINE_DEFINITIONS;
}

export function engineById(id: string): EngineDefinition | undefined {
  return ENGINE_DEFINITIONS.find(e => e.id === id);
}

export function envConfigured(engine: EngineDefinition): boolean {
  if (engine.tier === 'local') {
    const url = process.env[`${engine.provider.toUpperCase().replace(/-/g,'_')}_URL`] || process.env.LOCAL_TTS_URL;
    return Boolean(url);
  }
  return Boolean(engine.envKey && process.env[engine.envKey]);
}

export function catalogVoices(): Voice[] {
  return ENGINE_DEFINITIONS.map(e => ({
    voice_id: `${e.id}|${e.voiceId}`,
    name: `${e.name} • ${e.voiceId}`,
    category: e.tier === 'local' ? 'local' : 'api',
    description: e.description,
    labels: { engine: e.name, provider: e.provider, tier: e.tier, use_case: 'tts' }
  }));
}
