import { Readable } from 'node:stream';

export interface SpeechOptions {
  text: string;
  voiceId: string;
  modelId: string;
  stability: number;
  similarity_boost: number;
  style: number;
  speed: number;
  outputFormat: string;
  provider?: string;
}

export interface SpeechResult {
  audioBuffer: Buffer;
  contentType: string;
  format: string;
  provider: string;
}

function timeoutSignal(ms: number) {
  return AbortSignal.timeout(ms);
}

async function jsonError(res: Response, fallback: string): Promise<never> {
  const raw = await res.text();
  let msg = fallback;
  try {
    const j = JSON.parse(raw);
    msg = j?.detail?.message || j?.error?.message || j?.message || j?.error || fallback;
  } catch {}
  const err: any = new Error(`${msg} (HTTP ${res.status})`);
  err.statusCode = res.status;
  throw err;
}

async function fetchAudio(url: string, init: RequestInit, provider: string, format='mp3'): Promise<SpeechResult> {
  const res = await fetch(url, { ...init, signal: init.signal || timeoutSignal(120000) });
  if (!res.ok) await jsonError(res, `${provider} synthesis failed`);
  const ab = await res.arrayBuffer();
  const ct = res.headers.get('content-type') || (format === 'wav' ? 'audio/wav' : 'audio/mpeg');
  return { audioBuffer: Buffer.from(ab), contentType: ct, format, provider };
}

function splitModel(modelId: string) {
  const i = modelId.indexOf(':');
  return i > 0 ? [modelId.slice(0,i), modelId.slice(i+1)] : ['elevenlabs', modelId];
}

export class TTSService {
  async generateSpeech(o: SpeechOptions): Promise<SpeechResult> {
    const [provider, model] = splitModel(o.modelId);
    switch (provider) {
      case 'elevenlabs': return this.eleven(o, model);
      case 'openai': return this.openai(o, model);
      case 'deepgram': return this.deepgram(o, model);
      case 'cartesia': return this.cartesia(o, model);
      case 'gemini': return this.gemini(o, model);
      case 'azure': return this.azure(o, model);
      case 'local-kokoro':
      case 'local-piper':
      case 'local-chatterbox':
      case 'local-f5tts':
      case 'local-cosyvoice':
      case 'local-qwen3tts':
      case 'local-fishspeech':
        return this.local(o, provider, model);
      default: throw new Error(`Unknown TTS engine: ${provider}`);
    }
  }

  private async eleven(o: SpeechOptions, model: string): Promise<SpeechResult> {
    const key = process.env.ELEVENLABS_API_KEY;
    if (!key) throw new Error('ELEVENLABS_API_KEY is not configured.');
    const voice = o.voiceId.includes('|') ? o.voiceId.split('|').pop()! : o.voiceId;
    const url = `https://api.elevenlabs.io/v1/text-to-speech/${encodeURIComponent(voice)}/stream?output_format=${encodeURIComponent(o.outputFormat || 'mp3_44100_128')}`;
    return fetchAudio(url, {
      method:'POST', headers:{'xi-api-key':key,'Content-Type':'application/json','Accept':'audio/mpeg'},
      body:JSON.stringify({text:o.text, model_id:model, voice_settings:{
        stability:o.stability, similarity_boost:o.similarity_boost, style:o.style,
        use_speaker_boost:true, speed:o.speed
      }})
    }, 'ElevenLabs');
  }

  private async openai(o: SpeechOptions, model: string): Promise<SpeechResult> {
    const key=process.env.OPENAI_API_KEY;
    if(!key) throw new Error('OPENAI_API_KEY is not configured.');
    const voice=o.voiceId.includes('|') ? o.voiceId.split('|').pop()! : o.voiceId;
    const format = o.outputFormat.startsWith('wav') ? 'wav' : 'mp3';
    return fetchAudio('https://api.openai.com/v1/audio/speech',{
      method:'POST',headers:{Authorization:`Bearer ${key}`,'Content-Type':'application/json'},
      body:JSON.stringify({model,input:o.text,voice,response_format:format,speed:o.speed})
    },'OpenAI',format);
  }

  private async deepgram(o: SpeechOptions, model: string): Promise<SpeechResult> {
    const key=process.env.DEEPGRAM_API_KEY;
    if(!key) throw new Error('DEEPGRAM_API_KEY is not configured.');
    const url=`https://api.deepgram.com/v1/speak?model=${encodeURIComponent(model)}&encoding=mp3`;
    return fetchAudio(url,{method:'POST',headers:{Authorization:`Token ${key}`,'Content-Type':'application/json'},body:JSON.stringify({text:o.text})},'Deepgram','mp3');
  }

  private async cartesia(o: SpeechOptions, model: string): Promise<SpeechResult> {
    const key=process.env.CARTESIA_API_KEY;
    if(!key) throw new Error('CARTESIA_API_KEY is not configured.');
    const voice=o.voiceId.includes('|') ? o.voiceId.split('|').pop()! : o.voiceId;
    const url='https://api.cartesia.ai/tts/bytes';
    return fetchAudio(url,{method:'POST',headers:{
      'X-API-Key':key,'Cartesia-Version':'2025-04-16','Content-Type':'application/json'
    },body:JSON.stringify({
      model_id:model,transcript:o.text,voice:{mode:'id',id:voice},
      output_format:{container:'mp3',encoding:'mp3',sample_rate:44100,bit_rate:192}
    })},'Cartesia','mp3');
  }

  private async gemini(o: SpeechOptions, model: string): Promise<SpeechResult> {
    const key=process.env.GEMINI_API_KEY;
    if(!key) throw new Error('GEMINI_API_KEY is not configured.');
    const voice=o.voiceId.includes('|') ? o.voiceId.split('|').pop()! : o.voiceId;
    const prompt = `Perform the following text naturally. Style: cinematic, emotionally intelligent, human, clear. Pace: ${o.speed.toFixed(2)}x. ${o.text}`;
    const url=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(key)}`;
    const res=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},signal:timeoutSignal(120000),
      body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{responseModalities:['AUDIO'],speechConfig:{voiceConfig:{prebuiltVoiceConfig:{voiceName:voice}}}}})});
    if(!res.ok) await jsonError(res,'Gemini TTS failed');
    const j:any=await res.json();
    const data=j?.candidates?.[0]?.content?.parts?.find((p:any)=>p.inlineData)?.inlineData?.data;
    if(!data) throw new Error('Gemini returned no audio. Check model/voice availability.');
    return {audioBuffer:Buffer.from(data,'base64'),contentType:'audio/wav',format:'wav',provider:'Gemini'};
  }

  private async azure(o: SpeechOptions, _model: string): Promise<SpeechResult> {
    const key=process.env.AZURE_SPEECH_KEY;
    const region=process.env.AZURE_SPEECH_REGION;
    if(!key||!region) throw new Error('AZURE_SPEECH_KEY and AZURE_SPEECH_REGION are required.');
    const voice=o.voiceId.includes('|') ? o.voiceId.split('|').pop()! : o.voiceId;
    const ssml=`<speak version="1.0" xml:lang="en-US"><voice name="${voice}"><prosody rate="${Math.round((o.speed-1)*100)}%">${escapeXml(o.text)}</prosody></voice></speak>`;
    return fetchAudio(`https://${region}.tts.speech.microsoft.com/cognitiveservices/v1`,{method:'POST',headers:{
      'Ocp-Apim-Subscription-Key':key,'Content-Type':'application/ssml+xml','X-Microsoft-OutputFormat':'audio-24khz-96kbitrate-mono-mp3'
    },body:ssml},'Azure','mp3');
  }

  private async local(o: SpeechOptions, provider: string, model: string): Promise<SpeechResult> {
    const key=provider.toUpperCase().replace(/-/g,'_')+'_URL';
    const url=process.env[key] || process.env.LOCAL_TTS_URL;
    if(!url) throw new Error(`${provider} local server is not configured. Set ${key} or LOCAL_TTS_URL.`);
    const voice=o.voiceId.includes('|') ? o.voiceId.split('|').pop()! : o.voiceId;
    // Unified local gateway contract: POST /tts -> {audio_base64, content_type}
    const res=await fetch(`${url.replace(/\/$/,'')}/tts`,{
      method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({text:o.text,voice,model,provider,speed:o.speed,stability:o.stability,style:o.style,similarity:o.similarity_boost}),
      signal:timeoutSignal(180000)
    });
    if(!res.ok) await jsonError(res,`${provider} local synthesis failed`);
    const j:any=await res.json();
    if(!j?.audio_base64) throw new Error(`${provider} local gateway returned no audio`);
    return {audioBuffer:Buffer.from(j.audio_base64,'base64'),contentType:j.content_type||'audio/wav',format:'wav',provider};
  }
}

function escapeXml(s:string){return s.replace(/[<>&'"]/g,c=>({'<':'&lt;','>':'&gt;','&':'&amp;',"'":'&apos;','"':'&quot;'}[c]!));}
export const ttsService = new TTSService();
