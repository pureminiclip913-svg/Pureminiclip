import { Voice } from '../types.js';
import { catalogVoices, ENGINE_DEFINITIONS } from './engineRegistry.js';

const cache = new Map<string, Voice[]>();

export class VoiceService {
  async getVoices(forceRefresh=false): Promise<{voices:Voice[];provider:string;hasApiKey:boolean}> {
    if (!forceRefresh && cache.has('all')) return {voices:cache.get('all')!,provider:'multi-engine',hasApiKey:true};
    const voices = [...catalogVoices()];
    const key=process.env.ELEVENLABS_API_KEY;
    if(key){
      try{
        const r=await fetch('https://api.elevenlabs.io/v2/voices',{headers:{'xi-api-key':key}});
        if(r.ok){
          const j:any=await r.json();
          for(const v of (j.voices||[])){
            voices.push(v);
          }
        }
      }catch{}
    }
    cache.set('all',voices);
    return {voices,provider:'multi-engine',hasApiKey:Boolean(key)};
  }
  async getVoiceById(id:string):Promise<Voice|null>{
    const {voices}=await this.getVoices();
    return voices.find(v=>v.voice_id===id) || null;
  }
}
export const voiceService=new VoiceService();
