"""
VOXIA Local TTS Gateway
A single HTTP contract for free/open TTS engines.

Install:
  pip install fastapi uvicorn soundfile numpy
  # Optional engines:
  pip install kokoro piper-tts
  pip install chatterbox-tts
  # For F5/Qwen/CosyVoice/Fish use their official repositories and point
  # VOXIA to their HTTP server, or extend this adapter.

Run:
  uvicorn local_tts_gateway:app --host 0.0.0.0 --port 8099

POST /tts
{
  "provider":"local-kokoro",
  "model":"Kokoro-82M",
  "voice":"af_heart",
  "text":"Hello"
}
Returns JSON {audio_base64, content_type}.
"""
import base64, io, os, tempfile
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

app=FastAPI(title="VOXIA Local Neural TTS Gateway")

class TTSRequest(BaseModel):
    provider:str
    model:str=""
    voice:str=""
    text:str
    speed:float=1.0
    stability:float=.5
    style:float=0.0
    similarity:float=.75

def wav_bytes_from_tensor(wav, sample_rate):
    import soundfile as sf
    import numpy as np
    if hasattr(wav, "detach"): wav=wav.detach().cpu().numpy()
    wav=np.asarray(wav)
    if wav.ndim>1: wav=wav.squeeze()
    b=io.BytesIO()
    sf.write(b,wav,sample_rate,format="WAV")
    return b.getvalue()

@app.get("/health")
def health(): return {"status":"ok"}

@app.post("/tts")
def tts(r:TTSRequest):
    if not r.text.strip(): raise HTTPException(400,"text is empty")

    if r.provider=="local-kokoro":
        try:
            from kokoro import KPipeline
            import numpy as np, soundfile as sf
            lang = "a" if r.voice.startswith("a") else "b"
            pipe=KPipeline(lang_code=lang)
            chunks=[]
            for _,_,audio in pipe(r.text, voice=r.voice, speed=r.speed):
                chunks.append(np.asarray(audio))
            if not chunks: raise RuntimeError("Kokoro produced no audio")
            audio=np.concatenate(chunks)
            b=io.BytesIO(); sf.write(b,audio,24000,format="WAV")
            raw=b.getvalue()
        except Exception as e:
            raise HTTPException(500,f"Kokoro failed: {e}")

    elif r.provider=="local-piper":
        # Uses the piper CLI. Set PIPER_VOICE to a downloaded .onnx model.
        import subprocess
        voice=os.environ.get("PIPER_VOICE", r.voice)
        if not os.path.exists(voice):
            raise HTTPException(500,"Set PIPER_VOICE to a Piper .onnx voice model path.")
        p=subprocess.run(["python","-m","piper","--model",voice,"--output_raw"],input=r.text.encode(),capture_output=True)
        if p.returncode: raise HTTPException(500,p.stderr.decode()[:1000])
        # Piper raw output is 16-bit mono PCM; wrap WAV.
        import wave
        b=io.BytesIO()
        with wave.open(b,"wb") as w:
            w.setnchannels(1); w.setsampwidth(2); w.setframerate(22050); w.writeframes(p.stdout)
        raw=b.getvalue()

    else:
        # Other open models have rapidly changing server APIs. Keep a clean,
        # stable gateway contract and let their official HTTP servers be proxied
        # by this gateway in a future adapter.
        raise HTTPException(501,
          f"{r.provider} requires its official local server. Start it and configure "
          "LOCAL_TTS_URL to a compatible /tts gateway.")

    return {"audio_base64":base64.b64encode(raw).decode(),"content_type":"audio/wav"}
