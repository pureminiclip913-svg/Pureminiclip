import express, { Request, Response } from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';

import ttsRouter from './backend/routes/tts.js';
import voicesRouter from './backend/routes/voices.js';
import generationsRouter from './backend/routes/generations.js';
import projectsRouter from './backend/routes/projects.js';
import usageRouter from './backend/routes/usage.js';

import { storageService } from './backend/services/storageService.js';
import { rateLimiter } from './backend/middleware/rateLimit.js';
import { errorHandler } from './backend/middleware/errorHandler.js';
import { ENGINE_DEFINITIONS, envConfigured } from './backend/services/engineRegistry.js';

dotenv.config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = '0.0.0.0';

// CORS configuration dynamically driven by FRONTEND_URL
const configuredFrontendUrl = process.env.FRONTEND_URL || 'http://localhost:5173';
const configuredOrigins = configuredFrontendUrl
  .split(',')
  .map((url) => url.trim().replace(/\/$/, ''))
  .filter(Boolean);

const defaultAllowedOrigins = [
  'http://localhost:5173',
  'http://localhost:3000',
  'http://127.0.0.1:5173',
  'http://127.0.0.1:3000',
];

const allAllowedOrigins = Array.from(new Set([...configuredOrigins, ...defaultAllowedOrigins]));

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow requests with no origin (e.g. mobile apps, curl, server-to-server, same-origin)
      if (!origin) return callback(null, true);

      const normalizedOrigin = origin.replace(/\/$/, '');
      const isAllowed =
        allAllowedOrigins.includes(normalizedOrigin) ||
        allAllowedOrigins.some((allowed) => normalizedOrigin.startsWith(allowed)) ||
        normalizedOrigin.endsWith('.run.app');

      if (isAllowed) {
        return callback(null, true);
      }

      // In development mode, dynamically permit localhost dev servers on any port
      if (process.env.NODE_ENV !== 'production' && /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin)) {
        return callback(null, true);
      }

      return callback(new Error('CORS origin not allowed'));
    },
    credentials: true,
  })
);

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(rateLimiter);

// 1. Health check endpoint
app.get('/api/health', (req: Request, res: Response) => {
  const apiKey = process.env.ELEVENLABS_API_KEY;
  const hasValidApiKey = Boolean(apiKey && apiKey.trim().length > 5 && apiKey !== 'MY_ELEVENLABS_API_KEY');
  res.status(200).json({
    status: 'ok',
    service: 'VOXIA Neural TTS Router',
    version: '2.0.0',
    timestamp: new Date().toISOString(),
    elevenlabsConfigured: hasValidApiKey,
    engines: ENGINE_DEFINITIONS.map(e => ({id:e.id,name:e.name,configured:envConfigured(e),tier:e.tier})),
    frontendUrl: configuredFrontendUrl,
    environment: process.env.NODE_ENV || 'development',
  });
});

//  in-memory audio serving with HTTP 206 Range support (zero disk dependencies)
app.get('/api/audio/:fileName', (req: Request, res: Response) => {
  const { fileName } = req.params;
  const safeFileName = path.basename(fileName);
  const cached = storageService.getAudioBuffer(safeFileName);

  if (!cached) {
    res.status(404).json({
      success: false,
      error: { code: 'AUDIO_NOT_FOUND', message: 'Audio file not found or session has expired.' },
    });
    return;
  }

  const { buffer, contentType } = cached;
  const fileSize = buffer.length;
  const range = req.headers.range;

  if (range) {
    const parts = range.replace(/bytes=/, '').split('-');
    const start = parseInt(parts[0], 10);
    const end = parts[1] ? parseInt(parts[1], 10) : fileSize - 1;
    const chunksize = end - start + 1;
    const sliced = buffer.subarray(start, end + 1);

    res.writeHead(206, {
      'Content-Range': `bytes ${start}-${end}/${fileSize}`,
      'Accept-Ranges': 'bytes',
      'Content-Length': chunksize,
      'Content-Type': contentType,
    });
    res.end(sliced);
  } else {
    res.writeHead(200, {
      'Content-Length': fileSize,
      'Content-Type': contentType,
      'Accept-Ranges': 'bytes',
      'Cache-Control': 'public, max-age=3600',
    });
    res.end(buffer);
  }
});

// 3. API key validation/test endpoint
app.post('/api/settings/test-key', async (req: Request, res: Response) => {
  const { apiKey } = req.body || {};
  const keyToTest = apiKey || process.env.ELEVENLABS_API_KEY;

  if (!keyToTest || keyToTest.trim().length === 0) {
    res.status(400).json({
      success: false,
      message: 'No API key provided to test.',
    });
    return;
  }

  try {
    const checkRes = await fetch('https://api.elevenlabs.io/v1/user/subscription', {
      headers: { 'xi-api-key': keyToTest.trim() },
    });

    if (checkRes.ok) {
      const data = await checkRes.json() as any;
      res.status(200).json({
        success: true,
        valid: true,
        tier: data.tier || 'active',
        characterLimit: data.character_limit,
        characterCount: data.character_count,
        status: data.status,
      });
    } else {
      res.status(checkRes.status).json({
        success: false,
        valid: false,
        message: 'Invalid API key or unauthorized by ElevenLabs.',
      });
    }
  } catch (err: any) {
    res.status(500).json({
      success: false,
      valid: false,
      message: err?.message || 'Failed to reach ElevenLabs API.',
    });
  }
});

// 4. Mount core API routes
app.use('/api/tts', ttsRouter);
app.use('/api/voices', voicesRouter);
app.use('/api/generations', generationsRouter);
app.use('/api/projects', projectsRouter);
app.use('/api/usage', usageRouter);

// Centralized error handler for API routes
app.use('/api', errorHandler);

// 5. Mount Vite middleware for development or serve dist in production
async function setupFrontend() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }
}

setupFrontend().then(() => {
  app.listen(PORT, HOST, () => {
    console.log(`[VOXIA AI] Engine running on http://${HOST}:${PORT}`);
  });
});
